"""
End-to-end error analysis of lns_lib against FP32/FP16 references.

Two experiments:

  CORE  -- test values sized to mostly fall inside every format's range
           (including LNS8's narrow one), so the reported mean/max error
           reflects quantization precision rather than saturation.
  STRESS -- values spanning ~the full FP32 dynamic range, used to
            characterise overflow/underflow incidence per format.

Run: python analysis.py
"""

import os

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from lns_lib import (
    LNS16,
    LNS8,
    FP32,
    FP16,
    float_to_lns,
    lns_to_float,
    lns_add,
    lns_mul,
    lns_mac,
    error,
    ErrorStats,
)

np.seterr(over="ignore", invalid="ignore")  # non-finite refs are detected & skipped explicitly

RNG = np.random.default_rng(42)
FIGDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(FIGDIR, exist_ok=True)


def make_core_vectors(n_each=2000):
    vecs = {}
    vecs["zero"] = np.zeros(16)
    vecs["positive_small"] = RNG.uniform(1e-3, 1e-1, n_each)
    vecs["negative_small"] = -RNG.uniform(1e-3, 1e-1, n_each)
    vecs["positive_large"] = RNG.uniform(10.0, 200.0, n_each)
    vecs["negative_large"] = -RNG.uniform(10.0, 200.0, n_each)
    signs = RNG.choice([-1.0, 1.0], n_each)
    logmag = RNG.uniform(-7, 7, n_each)  # ~[0.0078, 128]
    vecs["random_loguniform"] = signs * (2.0 ** logmag)
    vecs["random_normal_dnn"] = RNG.normal(0.0, 0.05, n_each)
    return vecs


def make_stress_vectors(n=6000):
    signs = RNG.choice([-1.0, 1.0], n)
    logmag = RNG.uniform(-135, 125, n)
    return {"stress_wide_range": signs * (2.0 ** logmag)}


def all_values(vecs):
    return np.concatenate(list(vecs.values()))


def safe_ref(x, ref_dtype):
    """Cast into ref_dtype and back; None if that overflows to +/-inf."""
    rf = float(ref_dtype(x))
    return rf if np.isfinite(rf) else None


def evaluate_conversion(values, fmt, ref_dtype, in_range_only=False):
    stats = ErrorStats(label=f"{fmt.name} conv (ref={ref_dtype.__name__})")
    overflow_ct = underflow_ct = skipped = 0
    n_seen = 0
    for x in values:
        ref = safe_ref(x, ref_dtype)
        if ref is None:
            skipped += 1
            continue
        n_seen += 1
        v, flags = float_to_lns(ref, fmt, ref_dtype=ref_dtype)
        overflow_ct += flags["overflow"]
        underflow_ct += flags["underflow"]
        if in_range_only and (flags["overflow"] or flags["underflow"]):
            continue
        got = lns_to_float(v)
        stats.add(ref, got)
    return stats, overflow_ct, underflow_ct, skipped, n_seen


def make_pairs(values, n_pairs, rng):
    idx_a = rng.integers(0, len(values), n_pairs)
    idx_b = rng.integers(0, len(values), n_pairs)
    return values[idx_a], values[idx_b]


def evaluate_op(a_vals, b_vals, fmt, ref_dtype, op, in_range_only=False):
    stats = ErrorStats(label=f"{fmt.name} {op} (ref={ref_dtype.__name__})")
    overflow_ct = underflow_ct = skipped = 0
    n_seen = 0
    n = len(a_vals)
    c_vals = RNG.uniform(-1, 1, n) if op == "mac" else None

    for i in range(n):
        a_ref = safe_ref(a_vals[i], ref_dtype)
        b_ref = safe_ref(b_vals[i], ref_dtype)
        if a_ref is None or b_ref is None:
            skipped += 1
            continue

        va, fa = float_to_lns(a_ref, fmt, ref_dtype=ref_dtype)
        vb, fb = float_to_lns(b_ref, fmt, ref_dtype=ref_dtype)

        if op == "add":
            ref_result = safe_ref(ref_dtype(a_ref) + ref_dtype(b_ref), ref_dtype)
            r, flags = lns_add(va, vb)
        elif op == "mul":
            ref_result = safe_ref(ref_dtype(a_ref) * ref_dtype(b_ref), ref_dtype)
            r, flags = lns_mul(va, vb)
        elif op == "mac":
            c_ref = safe_ref(c_vals[i], ref_dtype)
            if c_ref is None:
                skipped += 1
                continue
            vc, fc = float_to_lns(c_ref, fmt, ref_dtype=ref_dtype)
            ref_result = safe_ref(ref_dtype(c_ref) + ref_dtype(a_ref) * ref_dtype(b_ref), ref_dtype)
            r, flags = lns_mac(vc, va, vb)
            flags = {
                "overflow": flags["overflow"] or fc["overflow"],
                "underflow": flags["underflow"] or fc["underflow"],
            }
        else:
            raise ValueError(op)

        if ref_result is None:
            skipped += 1
            continue

        any_overflow = flags["overflow"] or fa["overflow"] or fb["overflow"]
        any_underflow = flags["underflow"] or fa["underflow"] or fb["underflow"]
        overflow_ct += any_overflow
        underflow_ct += any_underflow
        n_seen += 1
        if in_range_only and (any_overflow or any_underflow):
            continue

        got = lns_to_float(r)
        stats.add(ref_result, got)

    return stats, overflow_ct, underflow_ct, skipped, n_seen


def print_format_table():
    print("=" * 104)
    print("Format geometry / representable range / worst-case quantization step")
    print("=" * 104)
    rows = [
        ("FP32", "1 sign + 8 exp + 23 mant",
         f"~{np.finfo(np.float32).tiny:.3e} .. {np.finfo(np.float32).max:.3e}",
         f"{2.0**-23 * 100:.6f} %"),
        ("FP16", "1 sign + 5 exp + 10 mant",
         f"~{np.finfo(np.float16).tiny:.3e} .. {np.finfo(np.float16).max:.3e}",
         f"{2.0**-10 * 100:.4f} %"),
        (LNS16.name, f"1 sign + {LNS16.int_bits} int + {LNS16.frac_bits} frac (log field)",
         f"~{LNS16.min_normal:.3e} .. {LNS16.max_normal:.3e}",
         f"{LNS16.max_step_relative_error * 100:.4f} %"),
        (LNS8.name, f"1 sign + {LNS8.int_bits} int + {LNS8.frac_bits} frac (log field)",
         f"~{LNS8.min_normal:.3e} .. {LNS8.max_normal:.3e}",
         f"{LNS8.max_step_relative_error * 100:.4f} %"),
    ]
    print(f"{'Format':<8}{'Layout':<32}{'Representable magnitude range':<38}{'Max quant. step (rel.)'}")
    for r in rows:
        print(f"{r[0]:<8}{r[1]:<32}{r[2]:<38}{r[3]}")
    print()


def main():
    print_format_table()

    core_vecs = make_core_vectors(n_each=2000)
    core_values = all_values(core_vecs)
    print(f"CORE test set size: {len(core_values)} (zero/small/large/positive/negative/random)\n")

    formats = [LNS16, LNS8]
    ref_dtypes = [FP32, FP16]

    print("=" * 104)
    print("CORE PRECISION TABLE -- round-trip conversion error (FP -> LNS -> FP), in-range samples only")
    print("=" * 104)
    conv_results = {}
    for fmt in formats:
        for ref_dtype in ref_dtypes:
            stats, ov, uv, sk, n = evaluate_conversion(core_values, fmt, ref_dtype, in_range_only=True)
            conv_results[(fmt.name, ref_dtype.__name__)] = stats
            print(f"{stats}  [overflow={ov}/{n} underflow={uv}/{n} skipped(out of ref range)={sk}]")
    print()

    print("=" * 104)
    print("CORE PRECISION TABLE -- arithmetic error (add / mul / mac), entirely in the LNS log domain, in-range samples only")
    print("=" * 104)
    n_pairs = 4000
    a_vals, b_vals = make_pairs(core_values, n_pairs, RNG)
    n_force = 200
    force_mag = 2.0 ** RNG.uniform(-6, 6, n_force)
    a_vals = np.concatenate([a_vals, force_mag])
    b_vals = np.concatenate([b_vals, -force_mag * RNG.uniform(0.98, 1.02, n_force)])

    op_results = {}
    for fmt in formats:
        for ref_dtype in ref_dtypes:
            for op in ("add", "mul", "mac"):
                stats, ov, uv, sk, n = evaluate_op(a_vals, b_vals, fmt, ref_dtype, op, in_range_only=True)
                op_results[(fmt.name, ref_dtype.__name__, op)] = stats
                print(f"{stats}  [overflow={ov}/{n} underflow={uv}/{n} skipped={sk}]")
    print()

    print("=" * 104)
    print("STRESS TEST -- overflow/underflow incidence across ~full FP32 dynamic range (ref=FP32)")
    print("=" * 104)
    stress_vecs = make_stress_vectors(n=8000)
    stress_values = all_values(stress_vecs)
    stress_summary = {}
    for fmt in formats:
        stats, ov, uv, sk, n = evaluate_conversion(stress_values, fmt, FP32, in_range_only=False)
        stress_summary[fmt.name] = (ov, uv, n)
        print(f"{fmt.name}: overflow={ov} ({100*ov/n:.1f}%)  underflow={uv} ({100*uv/n:.1f}%)  "
              f"in-range={n-ov-uv} ({100*(n-ov-uv)/n:.1f}%)  representable range={fmt.min_normal:.3e}..{fmt.max_normal:.3e}")
    print()

    plot_conversion_scatter(core_vecs, formats, FP32)
    plot_summary_bars(conv_results, op_results, formats, ref_dtypes)
    plot_range_diagram(formats)

    return conv_results, op_results, stress_summary


def plot_conversion_scatter(vecs, formats, ref_dtype):
    fig, axes = plt.subplots(1, len(formats), figsize=(12, 5), sharey=True)
    for ax, fmt in zip(axes, formats):
        xs, es = [], []
        for cat, arr in vecs.items():
            for x in arr:
                ref = safe_ref(x, ref_dtype)
                if ref is None or ref == 0.0:
                    continue
                v, flags = float_to_lns(ref, fmt, ref_dtype=ref_dtype)
                if flags["overflow"] or flags["underflow"]:
                    continue
                got = lns_to_float(v)
                xs.append(abs(ref))
                es.append(error(ref, got))
        ax.scatter(xs, es, s=4, alpha=0.3)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.axhline(fmt.max_step_relative_error, color="red", linestyle="--",
                    label=f"theoretical max step ({fmt.max_step_relative_error*100:.3f}%)")
        ax.set_title(f"{fmt.name} conversion error vs magnitude")
        ax.set_xlabel("|reference value| (log scale)")
        ax.legend(fontsize=8)
    axes[0].set_ylabel("relative error (log scale)")
    fig.tight_layout()
    path = os.path.join(FIGDIR, "conversion_error_scatter.png")
    fig.savefig(path, dpi=130)
    plt.close(fig)
    print(f"Saved {path}")


def plot_summary_bars(conv_results, op_results, formats, ref_dtypes):
    ops = ["add", "mul", "mac"]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    width = 0.18
    for ax, metric in zip(axes, ["mean", "max"]):
        labels = ["conv"] + ops
        x = np.arange(len(labels))
        offset = -1.5
        for fmt in formats:
            for ref_dtype in ref_dtypes:
                vals = [getattr(conv_results[(fmt.name, ref_dtype.__name__)], metric)]
                for op in ops:
                    vals.append(getattr(op_results[(fmt.name, ref_dtype.__name__, op)], metric))
                ax.bar(x + offset * width, vals, width=width,
                       label=f"{fmt.name}/{ref_dtype.__name__}")
                offset += 1
        ax.set_yscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_title(f"{metric} relative error (in-range samples)")
        ax.set_ylabel("relative error (log scale)")
    axes[0].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    path = os.path.join(FIGDIR, "error_summary_bars.png")
    fig.savefig(path, dpi=130)
    plt.close(fig)
    print(f"Saved {path}")


def plot_range_diagram(formats):
    fig, ax = plt.subplots(figsize=(10, 3))
    items = [
        ("FP32", np.finfo(np.float32).tiny, np.finfo(np.float32).max),
        ("FP16", np.finfo(np.float16).tiny, np.finfo(np.float16).max),
        ("LNS16", LNS16.min_normal, LNS16.max_normal),
        ("LNS8", LNS8.min_normal, LNS8.max_normal),
    ]
    for i, (name, lo, hi) in enumerate(items):
        ax.plot([np.log10(lo), np.log10(hi)], [i, i], linewidth=8, solid_capstyle="butt")
        ax.text(np.log10(hi) + 1, i, name, va="center")
    ax.set_yticks([])
    ax.set_xlabel("log10(representable positive magnitude)")
    ax.set_title("Representable dynamic range comparison")
    ax.set_xlim(-45, 50)
    fig.tight_layout()
    path = os.path.join(FIGDIR, "range_comparison.png")
    fig.savefig(path, dpi=130)
    plt.close(fig)
    print(f"Saved {path}")


if __name__ == "__main__":
    main()
