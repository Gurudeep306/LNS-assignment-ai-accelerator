"""
lns_lib.metrics

Error metrics for evaluating LNS conversion/arithmetic against FP32/FP16
references:

    relative_error = |x_ref - x_LNS| / |x_ref|   (x_ref != 0)
    relative_error = |x_ref - x_LNS|              (x_ref == 0, absolute error)
"""

from dataclasses import dataclass, field
from typing import List

import numpy as np


def error(ref: float, val: float) -> float:
    """Relative error, falling back to absolute error when ref == 0."""
    ref = float(ref)
    val = float(val)
    if ref == 0.0:
        return abs(val - ref)
    return abs(ref - val) / abs(ref)


@dataclass
class ErrorStats:
    label: str
    errors: List[float] = field(default_factory=list)

    def add(self, ref, val):
        self.errors.append(error(ref, val))

    @property
    def mean(self) -> float:
        return float(np.mean(self.errors)) if self.errors else float("nan")

    @property
    def max(self) -> float:
        return float(np.max(self.errors)) if self.errors else float("nan")

    @property
    def median(self) -> float:
        return float(np.median(self.errors)) if self.errors else float("nan")

    @property
    def count(self) -> int:
        return len(self.errors)

    def as_dict(self):
        return {
            "label": self.label,
            "count": self.count,
            "mean": self.mean,
            "median": self.median,
            "max": self.max,
        }

    def __repr__(self):
        return (
            f"{self.label:<28} n={self.count:<6} "
            f"mean={self.mean:.6e}  median={self.median:.6e}  max={self.max:.6e}"
        )
