"""
lns_lib -- a Logarithmic Number System (LNS) arithmetic library for DNN
computation experiments.

Formats: LNSFormat, LNS16, LNS8
Conversion: LNSValue, float_to_lns, lns_to_float, lns_to_fp32, lns_to_fp16
Arithmetic (log domain): lns_add, lns_sub, lns_mul, lns_mac, lns_dot,
    lns_add_lut, build_fplus_fminus_lut
Error metrics: error, ErrorStats
"""

from .format import LNSFormat, LNS16, LNS8
from .convert import LNSValue, float_to_lns, lns_to_float, lns_to_fp32, lns_to_fp16, FP32, FP16
from .arithmetic import (
    lns_add,
    lns_sub,
    lns_mul,
    lns_mac,
    lns_dot,
    lns_add_lut,
    build_fplus_fminus_lut,
)
from .metrics import error, ErrorStats

__all__ = [
    "LNSFormat",
    "LNS16",
    "LNS8",
    "LNSValue",
    "float_to_lns",
    "lns_to_float",
    "lns_to_fp32",
    "lns_to_fp16",
    "FP32",
    "FP16",
    "lns_add",
    "lns_sub",
    "lns_mul",
    "lns_mac",
    "lns_dot",
    "lns_add_lut",
    "build_fplus_fminus_lut",
    "error",
    "ErrorStats",
]

__version__ = "0.1.0"
