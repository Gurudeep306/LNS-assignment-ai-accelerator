"""
lns_lib.format

Bit layout for the two fixed-point LNS formats: LNS16 and LNS8.

Encoding: [ sign_bit (1) | log-magnitude, two's-complement fixed point (total_bits-1 bits) ]

The log-magnitude field is a signed fixed-point number representing
L = log2(|x|), split into int_bits (integer part, includes the field's
own sign) and frac_bits (fractional part). A field value c represents
c / 2**frac_bits.

log2(0) = -infinity, which has no finite representation, so the most
negative code of the log field is reserved and always decodes to 0.0
(same trick IEEE-754 uses for signed zero).

Any result above the max representable code saturates to it (overflow);
any result at or below the reserved zero code flushes to zero
(underflow). Both are reported back via a flags dict.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class LNSFormat:
    """A fixed-point LNS number format.

    name: human readable name, e.g. "LNS16".
    total_bits: total storage width (1 sign bit + log-magnitude field).
    int_bits: integer bits of the two's-complement log-magnitude field
        (includes that field's own sign).
    frac_bits: fractional bits of the log-magnitude field.
    """

    name: str
    total_bits: int
    int_bits: int
    frac_bits: int

    def __post_init__(self):
        if self.int_bits + self.frac_bits != self.total_bits - 1:
            raise ValueError(
                f"{self.name}: int_bits ({self.int_bits}) + frac_bits "
                f"({self.frac_bits}) must equal total_bits-1 "
                f"({self.total_bits - 1}); 1 bit is reserved for the "
                f"value's sign."
            )
        if self.int_bits < 1 or self.frac_bits < 0:
            raise ValueError(f"{self.name}: invalid int_bits/frac_bits split")

    @property
    def mag_bits(self) -> int:
        return self.int_bits + self.frac_bits

    @property
    def scale(self) -> int:
        """2**frac_bits: multiply a real log2 value by this to get the
        fixed-point integer code (before rounding)."""
        return 1 << self.frac_bits

    @property
    def logmag_min(self) -> int:
        """Most negative code; reserved as the zero sentinel."""
        return -(1 << (self.mag_bits - 1))

    @property
    def logmag_max(self) -> int:
        return (1 << (self.mag_bits - 1)) - 1

    @property
    def zero_code(self) -> int:
        return self.logmag_min

    @property
    def smallest_normal_logmag(self) -> int:
        return self.logmag_min + 1

    @property
    def L_min_real(self) -> float:
        return self.smallest_normal_logmag / self.scale

    @property
    def L_max_real(self) -> float:
        return self.logmag_max / self.scale

    @property
    def min_normal(self) -> float:
        return 2.0 ** self.L_min_real

    @property
    def max_normal(self) -> float:
        return 2.0 ** self.L_max_real

    @property
    def max_step_relative_error(self) -> float:
        """Worst-case relative quantization error from rounding L to the
        nearest code: half an ULP of the log field, converted to the
        linear domain."""
        half_ulp = 0.5 / self.scale
        return abs(2.0 ** half_ulp - 1.0)

    def describe(self) -> str:
        return (
            f"{self.name}: {self.total_bits} bits total "
            f"(1 sign + {self.int_bits} int + {self.frac_bits} frac log-field), "
            f"range [{self.min_normal:.6g}, {self.max_normal:.6g}], "
            f"max quantization step (relative) ~{self.max_step_relative_error * 100:.3f}%"
        )


# LNS16: 8/7 split -> log2 range +/-128, i.e. ~2^-128..2^127.99, chosen to
# bracket FP32's dynamic range (~2^-126..2^128 for normals).
LNS16 = LNSFormat(name="LNS16", total_bits=16, int_bits=8, frac_bits=7)

# LNS8: 4/3 split -> log2 range +/-8, i.e. ~2^-8..2^7.875, a narrow 8-bit
# format representative of low-precision DNN accumulator/weight formats.
LNS8 = LNSFormat(name="LNS8", total_bits=8, int_bits=4, frac_bits=3)
