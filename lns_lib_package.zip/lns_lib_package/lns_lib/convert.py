"""
lns_lib.convert

Conversion between IEEE floating point (FP32/FP16, via numpy) and the
fixed-point LNS formats in lns_lib.format.

LNSValue (a sign bit + integer log-magnitude code) is what arithmetic
operates on directly; lns_to_float is only used at the edges, to compare
an LNS result against a floating point reference.
"""

import math
from dataclasses import dataclass

import numpy as np

from .format import LNSFormat

FP32 = np.float32
FP16 = np.float16


def _round_half_away_from_zero(x: float) -> int:
    """Round to the nearest integer, ties away from zero (plain
    fixed-point rounding, not Python's round-half-to-even)."""
    if x >= 0:
        return math.floor(x + 0.5)
    return -math.floor(-x + 0.5)


@dataclass(frozen=True)
class LNSValue:
    """An encoded LNS number: a sign bit plus an integer log-magnitude
    code. logmag == fmt.logmag_min is the reserved zero sentinel."""

    sign: int  # 0 or 1
    logmag: int
    fmt: LNSFormat

    def __post_init__(self):
        if self.sign not in (0, 1):
            raise ValueError("sign must be 0 or 1")
        if not (self.fmt.logmag_min <= self.logmag <= self.fmt.logmag_max):
            raise ValueError(
                f"logmag code {self.logmag} out of range for {self.fmt.name}"
            )

    @property
    def is_zero(self) -> bool:
        return self.logmag == self.fmt.logmag_min

    def to_bits(self) -> int:
        """Pack into a single unsigned integer of fmt.total_bits bits,
        as it would sit in a hardware register."""
        mask = (1 << self.fmt.mag_bits) - 1
        mag_field = self.logmag & mask
        return (self.sign << self.fmt.mag_bits) | mag_field

    @classmethod
    def from_bits(cls, bits: int, fmt: LNSFormat) -> "LNSValue":
        mag_mask = (1 << fmt.mag_bits) - 1
        sign = (bits >> fmt.mag_bits) & 1
        raw = bits & mag_mask
        if raw & (1 << (fmt.mag_bits - 1)):  # sign-extend
            raw -= 1 << fmt.mag_bits
        return cls(sign=sign, logmag=raw, fmt=fmt)

    def __repr__(self):
        return (
            f"LNSValue({'-' if self.sign else '+'}, logmag={self.logmag}, "
            f"fmt={self.fmt.name}, value~={lns_to_float(self):.6g})"
        )


def _quantize_log(L: float, fmt: LNSFormat):
    """Quantize a real log2 magnitude to the format's fixed-point grid.
    Returns (code, flags)."""
    flags = {"overflow": False, "underflow": False}
    code = _round_half_away_from_zero(L * fmt.scale)
    if code > fmt.logmag_max:
        flags["overflow"] = True
        return fmt.logmag_max, flags
    if code <= fmt.logmag_min:
        flags["underflow"] = True
        return fmt.logmag_min, flags
    return code, flags


def float_to_lns(x, fmt: LNSFormat, ref_dtype=FP32):
    """Convert a real number to an LNSValue in format fmt.

    x is first snapped to ref_dtype (np.float32 or np.float16), modeling
    "quantize this FP32/FP16 value into LNS". Returns (LNSValue, flags).
    """
    xq = ref_dtype(x)
    xq_f = float(xq)

    if math.isnan(xq_f):
        raise ValueError("NaN has no LNS representation")

    if xq_f == 0.0:
        return LNSValue(0, fmt.logmag_min, fmt), {"overflow": False, "underflow": False}

    if math.isinf(xq_f):
        sign = 1 if xq_f < 0 else 0
        return LNSValue(sign, fmt.logmag_max, fmt), {"overflow": True, "underflow": False}

    sign = 1 if xq_f < 0 else 0
    mag = abs(xq_f)
    L = math.log2(mag)
    code, flags = _quantize_log(L, fmt)
    return LNSValue(sign, code, fmt), flags


def lns_to_float(v: LNSValue) -> float:
    """Decode an LNSValue back to a double-precision float. Only used for
    reporting/error analysis, never as an intermediate arithmetic step."""
    if v.is_zero:
        return 0.0
    L = v.logmag / v.fmt.scale
    mag = 2.0 ** L
    return -mag if v.sign else mag


def lns_to_fp32(v: LNSValue) -> np.float32:
    return np.float32(lns_to_float(v))


def lns_to_fp16(v: LNSValue) -> np.float16:
    return np.float16(lns_to_float(v))
