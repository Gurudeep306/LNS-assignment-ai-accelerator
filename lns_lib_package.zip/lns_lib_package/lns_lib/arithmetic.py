"""
lns_lib.arithmetic

Addition, multiplication and multiply-accumulate performed entirely in
the log domain. Operands and results are LNSValue objects; an operand is
never converted back to a linear float in order to compute a result.

Multiplication is exact: log2(a*b) = log2(a) + log2(b), signs XOR. The
only error is the final re-quantization/saturation of the summed code.

Addition has no closed-form log-domain identity, so it uses the classical
Gaussian-logarithm method. With La = log2(|a|), Lb = log2(|b|), and
(after swapping so La >= Lb) r = Lb - La <= 0:

    same sign:     log2(|a|+|b|) = La + log2(1 + 2**r)      =: La + F+(r)
    opposite sign: log2(|a|-|b|) = La + log2(|1 - 2**r|)    =: La + F-(r)

F+ and F- depend only on r -- the difference of the two log codes, never
the operands' magnitudes. In hardware, r comes from an integer subtract
of the log fields and F+/F- are a lookup table indexed by r; here they're
evaluated with math.log2/** as a bit-accurate stand-in for that table
(see build_fplus_fminus_lut for an explicit, literally tabulated version).
"""

import math

from .convert import LNSValue, _round_half_away_from_zero
from .format import LNSFormat


def _saturate(code: int, fmt: LNSFormat):
    flags = {"overflow": False, "underflow": False}
    if code > fmt.logmag_max:
        flags["overflow"] = True
        return fmt.logmag_max, flags
    if code <= fmt.logmag_min:
        flags["underflow"] = True
        return fmt.logmag_min, flags
    return code, flags


def lns_mul(a: LNSValue, b: LNSValue):
    """Exact log-domain multiplication: logmags add, signs XOR."""
    if a.fmt is not b.fmt:
        raise ValueError("operands must share the same LNSFormat")
    fmt = a.fmt

    if a.is_zero or b.is_zero:
        return LNSValue(0, fmt.logmag_min, fmt), {"overflow": False, "underflow": False}

    sign = a.sign ^ b.sign
    raw = a.logmag + b.logmag
    code, flags = _saturate(raw, fmt)
    return LNSValue(sign, code, fmt), flags


def _fplus(r: float) -> float:
    """F+(r) = log2(1 + 2**r), r <= 0."""
    return math.log2(1.0 + 2.0 ** r)


def _fminus(r: float) -> float:
    """F-(r) = log2(|1 - 2**r|), r < 0 (r == 0 is exact cancellation,
    handled by the caller)."""
    return math.log2(abs(1.0 - 2.0 ** r))


def lns_add(a: LNSValue, b: LNSValue):
    """Add two LNS values via the Gaussian-logarithm method."""
    if a.fmt is not b.fmt:
        raise ValueError("operands must share the same LNSFormat")
    fmt = a.fmt

    if a.is_zero:
        return b, {"overflow": False, "underflow": False}
    if b.is_zero:
        return a, {"overflow": False, "underflow": False}

    if a.logmag >= b.logmag:
        big, small = a, b
    else:
        big, small = b, a

    if big.logmag == small.logmag and big.sign != small.sign:
        return LNSValue(0, fmt.logmag_min, fmt), {"overflow": False, "underflow": False}

    r = (small.logmag - big.logmag) / fmt.scale

    if big.sign == small.sign:
        delta = _fplus(r)
    else:
        delta = _fminus(r)
    result_sign = big.sign

    raw = big.logmag + _round_half_away_from_zero(delta * fmt.scale)
    code, flags = _saturate(raw, fmt)

    if code == fmt.logmag_min:
        return LNSValue(0, fmt.logmag_min, fmt), flags
    return LNSValue(result_sign, code, fmt), flags


def lns_sub(a: LNSValue, b: LNSValue):
    """a - b, via a + (-b); flipping the sign bit is exact."""
    fmt = a.fmt
    neg_b = b if b.is_zero else LNSValue(1 - b.sign, b.logmag, fmt)
    return lns_add(a, neg_b)


def lns_mac(acc: LNSValue, a: LNSValue, b: LNSValue):
    """acc + a*b, entirely in the log domain."""
    prod, flags_mul = lns_mul(a, b)
    result, flags_add = lns_add(acc, prod)
    flags = {
        "overflow": flags_mul["overflow"] or flags_add["overflow"],
        "underflow": flags_mul["underflow"] or flags_add["underflow"],
    }
    return result, flags


def lns_dot(acc: LNSValue, a_list, b_list):
    """acc + sum(a_i * b_i) via repeated lns_mac."""
    flags = {"overflow": False, "underflow": False}
    for a, b in zip(a_list, b_list):
        acc, f = lns_mac(acc, a, b)
        flags["overflow"] = flags["overflow"] or f["overflow"]
        flags["underflow"] = flags["underflow"] or f["underflow"]
    return acc, flags


# Explicit, literally-tabulated F+/F- lookup table -- mirrors how a real
# LNS adder would implement addition (a small ROM indexed by the
# quantized difference r), and serves as a correctness cross-check
# against the closed-form lns_add above.

_LUT_CACHE = {}


def build_fplus_fminus_lut(fmt: LNSFormat):
    """Build (and cache) quantized F+/F- lookup tables for fmt, indexed
    by k = |Lbig - Lsmall| over every value that difference can take."""
    key = fmt.name
    if key in _LUT_CACHE:
        return _LUT_CACHE[key]

    span = fmt.logmag_max - fmt.logmag_min
    fplus = {}
    fminus = {}
    for k in range(0, span + 1):
        r = -k / fmt.scale
        fplus[k] = _round_half_away_from_zero(_fplus(r) * fmt.scale)
        fminus[k] = None if k == 0 else _round_half_away_from_zero(_fminus(r) * fmt.scale)
    _LUT_CACHE[key] = (fplus, fminus)
    return fplus, fminus


def lns_add_lut(a: LNSValue, b: LNSValue):
    """Same as lns_add, but F+/F- come from a precomputed lookup table
    indexed by the integer difference of the log codes, matching lns_add
    to within its own rounding."""
    fmt = a.fmt
    if a.is_zero:
        return b, {"overflow": False, "underflow": False}
    if b.is_zero:
        return a, {"overflow": False, "underflow": False}

    if a.logmag >= b.logmag:
        big, small = a, b
    else:
        big, small = b, a

    if big.logmag == small.logmag and big.sign != small.sign:
        return LNSValue(0, fmt.logmag_min, fmt), {"overflow": False, "underflow": False}

    k = big.logmag - small.logmag
    fplus, fminus = build_fplus_fminus_lut(fmt)
    delta_code = fplus[k] if big.sign == small.sign else fminus[k]
    result_sign = big.sign

    raw = big.logmag + delta_code
    code, flags = _saturate(raw, fmt)
    if code == fmt.logmag_min:
        return LNSValue(0, fmt.logmag_min, fmt), flags
    return LNSValue(result_sign, code, fmt), flags
