"""
Correctness tests for lns_lib.

Run with: python -m pytest tests/ -v
or: python tests/test_lns.py
"""

import math
import random
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from lns_lib import (
    LNS16,
    LNS8,
    float_to_lns,
    lns_to_float,
    lns_add,
    lns_sub,
    lns_mul,
    lns_mac,
    lns_add_lut,
    error,
)


def approx(a, b, tol):
    return abs(a - b) <= tol


def test_zero_roundtrip():
    for fmt in (LNS16, LNS8):
        v, flags = float_to_lns(0.0, fmt)
        assert v.is_zero
        assert lns_to_float(v) == 0.0
        assert not flags["overflow"] and not flags["underflow"]


def test_sign_roundtrip():
    for fmt in (LNS16, LNS8):
        for x in (1.0, -1.0, 3.5, -3.5):
            v, _ = float_to_lns(x, fmt)
            back = lns_to_float(v)
            assert (back < 0) == (x < 0) or x == 0
            assert error(x, back) < fmt.max_step_relative_error * 1.01


def test_roundtrip_precision_bound():
    random.seed(0)
    for fmt in (LNS16, LNS8):
        worst = 0.0
        for _ in range(5000):
            L = random.uniform(fmt.L_min_real + 1, fmt.L_max_real - 1)
            sign = random.choice([1, -1])
            x = sign * (2.0 ** L)
            v, flags = float_to_lns(x, fmt)
            assert not flags["overflow"] and not flags["underflow"]
            back = lns_to_float(v)
            e = error(x, back)
            worst = max(worst, e)
        assert worst <= fmt.max_step_relative_error * 1.05, (fmt.name, worst)


def test_multiplication_exactness():
    """Multiplication should introduce no error beyond what conversion
    already introduced in the two operands."""
    random.seed(1)
    for fmt in (LNS16, LNS8):
        for _ in range(2000):
            La = random.uniform(fmt.L_min_real / 2, fmt.L_max_real / 2)
            Lb = random.uniform(fmt.L_min_real / 2, fmt.L_max_real / 2)
            a = random.choice([1, -1]) * 2.0 ** La
            b = random.choice([1, -1]) * 2.0 ** Lb
            va, _ = float_to_lns(a, fmt)
            vb, _ = float_to_lns(b, fmt)
            prod, flags = lns_mul(va, vb)
            if flags["overflow"] or flags["underflow"]:
                continue
            got = lns_to_float(prod)
            ref = lns_to_float(va) * lns_to_float(vb)
            assert error(ref, got) < fmt.max_step_relative_error * 1.05


def test_addition_same_sign():
    fmt = LNS16
    a, _ = float_to_lns(3.0, fmt)
    b, _ = float_to_lns(4.0, fmt)
    r, flags = lns_add(a, b)
    assert approx(lns_to_float(r), 7.0, 7.0 * fmt.max_step_relative_error * 2)


def test_addition_opposite_sign_cancellation():
    fmt = LNS16
    a, _ = float_to_lns(5.0, fmt)
    b, _ = float_to_lns(-5.0, fmt)
    r, flags = lns_add(a, b)
    assert r.is_zero
    assert lns_to_float(r) == 0.0


def test_addition_opposite_sign_general():
    fmt = LNS16
    a, _ = float_to_lns(10.0, fmt)
    b, _ = float_to_lns(-3.0, fmt)
    r, flags = lns_add(a, b)
    got = lns_to_float(r)
    assert approx(got, 7.0, 7.0 * fmt.max_step_relative_error * 3)


def test_addition_identity_with_zero():
    fmt = LNS8
    a, _ = float_to_lns(2.5, fmt)
    z, _ = float_to_lns(0.0, fmt)
    r1, _ = lns_add(a, z)
    r2, _ = lns_add(z, a)
    assert lns_to_float(r1) == lns_to_float(a)
    assert lns_to_float(r2) == lns_to_float(a)


def test_subtraction():
    fmt = LNS16
    a, _ = float_to_lns(9.0, fmt)
    b, _ = float_to_lns(4.0, fmt)
    r, _ = lns_sub(a, b)
    assert approx(lns_to_float(r), 5.0, 5.0 * fmt.max_step_relative_error * 3)


def test_mac():
    fmt = LNS16
    acc, _ = float_to_lns(1.0, fmt)
    a, _ = float_to_lns(2.0, fmt)
    b, _ = float_to_lns(3.0, fmt)
    r, _ = lns_mac(acc, a, b)  # 1 + 2*3 = 7
    assert approx(lns_to_float(r), 7.0, 7.0 * fmt.max_step_relative_error * 3)


def test_overflow_saturates():
    fmt = LNS8
    big, flags = float_to_lns(1e10, fmt)  # beyond LNS8 range (~234.8 max)
    assert flags["overflow"]
    assert big.logmag == fmt.logmag_max


def test_underflow_flushes_to_zero():
    fmt = LNS8
    tiny, flags = float_to_lns(1e-10, fmt)  # below LNS8 range (~0.0039 min)
    assert flags["underflow"]
    assert tiny.is_zero


def test_add_matches_lut_variant():
    random.seed(2)
    fmt = LNS8
    for _ in range(500):
        a_f = random.choice([1, -1]) * (2.0 ** random.uniform(-6, 6))
        b_f = random.choice([1, -1]) * (2.0 ** random.uniform(-6, 6))
        va, _ = float_to_lns(a_f, fmt)
        vb, _ = float_to_lns(b_f, fmt)
        r1, _ = lns_add(va, vb)
        r2, _ = lns_add_lut(va, vb)
        assert r1.sign == r2.sign and r1.logmag == r2.logmag


def test_bit_packing_roundtrip():
    for fmt in (LNS16, LNS8):
        for x in (0.0, 1.0, -1.0, 123.0, -0.001):
            v, flags = float_to_lns(x, fmt)
            bits = v.to_bits()
            assert 0 <= bits < (1 << fmt.total_bits)
            from lns_lib import LNSValue
            v2 = LNSValue.from_bits(bits, fmt)
            assert v2.sign == v.sign and v2.logmag == v.logmag


def _run_all():
    tests = [obj for name, obj in list(globals().items()) if name.startswith("test_")]
    passed = 0
    for t in tests:
        t()
        passed += 1
        print(f"OK   {t.__name__}")
    print(f"\n{passed}/{len(tests)} tests passed")


if __name__ == "__main__":
    _run_all()
